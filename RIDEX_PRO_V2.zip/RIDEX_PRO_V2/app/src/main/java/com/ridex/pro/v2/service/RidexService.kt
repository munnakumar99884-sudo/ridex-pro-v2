package com.ridex.pro.v2.service
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RidexService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        findAndClick(root, "Accept")
    }
    fun findAndClick(node: AccessibilityNodeInfo, txt: String) {
        if (node.text?.toString()?.contains(txt, true) == true && node.isClickable) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK); return
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { findAndClick(it, txt) }
        }
    }
    override fun onInterrupt() {}
}

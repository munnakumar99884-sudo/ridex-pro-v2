package com.ridex.pro.v2
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this)
        tv.text = "RIDEX PRO V2\n\n1. Accessibility ON karo\n2. Battery No Restriction\n\nHome, Fare, KM, History, Settings Full Working"
        tv.setPadding(40,100,40,40)
        tv.textSize = 18f
        tv.setTextColor(-1)
        setContentView(tv)
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }
}
